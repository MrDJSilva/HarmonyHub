<?php
declare(strict_types=1);
header('Content-Type: application/json');
require dirname(__DIR__).'/auth.php';
require_login();
require dirname(__DIR__).'/config.php';
function fail(string $message,int $status=400):never {http_response_code($status);echo json_encode(['error'=>$message]);exit;}
function rows(PDO $db,string $sql,array $params=[]):array {$s=$db->prepare($sql);$s->execute($params);return $s->fetchAll();}
function one(PDO $db,string $sql,array $params=[]):?array {return rows($db,$sql,$params)[0]??null;}
function rate(int $duration):float {return [30=>35,45=>50,60=>65][$duration]??0;}
function validStatus(string $s):bool {return in_array($s,['scheduled','confirmed','completed','cancelled','no-show'],true);}
function conflict(PDO $db,int $student,int $teacher,string $start,int $duration,string $room,int $exclude=0):bool {
 $end=date('Y-m-d H:i:s',strtotime($start)+$duration*60);
 $sql="SELECT id FROM lessons WHERE status<>'cancelled' AND id<>? AND starts_at < ? AND DATE_ADD(starts_at, INTERVAL duration MINUTE)>? AND (teacher_id=? OR student_id=? OR room=?) LIMIT 1";
 return one($db,$sql,[$exclude,$end,$start,$teacher,$student,$room])!==null;
}
try {
 $action=$_GET['action']??'overview';
 $input=json_decode(file_get_contents('php://input'),true)??[];
 if($_SESSION['role']!=='admin')fail('Teacher access is not yet enabled for student or finance data',403);
 if($action==='overview') {
  $from=$_GET['from']??date('Y-m-d',strtotime('monday this week'));
  $to=$_GET['to']??date('Y-m-d',strtotime($from.' +7 days'));
  $studentBalances=rows($pdo,"SELECT s.id, COALESCE(l.unpaid,0)+COALESCE(b.unpaid,0) outstanding, COALESCE(l.paid,0)+COALESCE(b.paid,0)-COALESCE(r.refunded,0) net_paid, COALESCE(r.refunded,0) refunded FROM students s LEFT JOIN (SELECT student_id,SUM(CASE WHEN payment_status='unpaid' AND status<>'cancelled' THEN price ELSE 0 END) unpaid,SUM(CASE WHEN payment_status='paid' THEN price ELSE 0 END) paid FROM lessons WHERE bundle_id IS NULL GROUP BY student_id) l ON l.student_id=s.id LEFT JOIN (SELECT student_id,SUM(CASE WHEN status='unpaid' THEN total ELSE 0 END) unpaid,SUM(CASE WHEN status='paid' THEN total ELSE 0 END) paid FROM bundles GROUP BY student_id) b ON b.student_id=s.id LEFT JOIN (SELECT student_id,SUM(amount) refunded FROM refunds WHERE status='processed' GROUP BY student_id) r ON r.student_id=s.id");
  $prepaid=rows($pdo,"SELECT student_id,
    COALESCE(SUM(CASE WHEN status='paid' THEN credits_remaining ELSE 0 END),0) prepaid_lessons,
    COALESCE(SUM(CASE WHEN status='paid' AND credits_total>0 THEN total*credits_remaining/credits_total ELSE 0 END),0) prepaid_value,
    COALESCE(SUM(CASE WHEN status='unpaid' THEN credits_remaining ELSE 0 END),0) unpaid_bundle_lessons
    FROM bundles GROUP BY student_id");
  $prepaidByStudent=[];
  foreach($prepaid as $credit){$prepaidByStudent[(int)$credit['student_id']]=$credit;}
  foreach($studentBalances as &$balanceRow){
    $credit=$prepaidByStudent[(int)$balanceRow['id']]??null;
    $balanceRow['prepaid_lessons']=$credit['prepaid_lessons']??0;
    $balanceRow['prepaid_value']=$credit['prepaid_value']??0;
    $balanceRow['unpaid_bundle_lessons']=$credit['unpaid_bundle_lessons']??0;
  }
  unset($balanceRow);
  echo json_encode(['student_balances'=>$studentBalances,'teachers'=>rows($pdo,'SELECT * FROM teachers ORDER BY name'),'students'=>rows($pdo,'SELECT * FROM students ORDER BY name'),'lessons'=>rows($pdo,"SELECT l.*,s.name student,t.name teacher,t.instrument FROM lessons l JOIN students s ON s.id=l.student_id JOIN teachers t ON t.id=l.teacher_id WHERE l.starts_at>=? AND l.starts_at<? ORDER BY l.starts_at",[$from,$to]),'bundles'=>rows($pdo,'SELECT b.*,s.name student FROM bundles b JOIN students s ON s.id=b.student_id ORDER BY b.id DESC'), 'payments'=>rows($pdo,"SELECT 'lesson' type,l.id,s.name student,l.price amount,l.payment_status status,l.due_date FROM lessons l JOIN students s ON s.id=l.student_id WHERE l.bundle_id IS NULL AND (l.status<>'cancelled' OR l.payment_status='paid') UNION ALL SELECT 'bundle' type,b.id,s.name student,b.total amount,b.status,b.due_date FROM bundles b JOIN students s ON s.id=b.student_id ORDER BY due_date DESC"), 'revenue'=>one($pdo,"SELECT COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) paid,COALESCE(SUM(CASE WHEN status='unpaid' THEN amount ELSE 0 END),0) unpaid,COALESCE(SUM(CASE WHEN status='unpaid' AND due_date<CURDATE() THEN amount ELSE 0 END),0) overdue FROM (SELECT price amount,payment_status status,due_date FROM lessons WHERE bundle_id IS NULL AND (status<>'cancelled' OR payment_status='paid') UNION ALL SELECT total amount,status,due_date FROM bundles) x")]);exit;
 }
 if($action==='student_history'){
  $id=(int)($_GET['id']??0);if($id<1)fail('Invalid student');
  $student=one($pdo,'SELECT * FROM students WHERE id=?',[$id]);if(!$student)fail('Student not found',404);
  $history=rows($pdo,'SELECT l.*,t.name teacher,t.instrument FROM lessons l JOIN teachers t ON t.id=l.teacher_id WHERE l.student_id=? ORDER BY l.starts_at DESC,l.id DESC',[$id]);
  $bundles=rows($pdo,'SELECT * FROM bundles WHERE student_id=? ORDER BY created_at DESC',[$id]);
  $balance=one($pdo,"SELECT COALESCE((SELECT SUM(price) FROM lessons WHERE student_id=? AND bundle_id IS NULL AND payment_status='unpaid' AND status<>'cancelled'),0)+COALESCE((SELECT SUM(total) FROM bundles WHERE student_id=? AND status='unpaid'),0) outstanding,COALESCE((SELECT SUM(price) FROM lessons WHERE student_id=? AND bundle_id IS NULL AND payment_status='paid'),0)+COALESCE((SELECT SUM(total) FROM bundles WHERE student_id=? AND status='paid'),0)-COALESCE((SELECT SUM(amount) FROM refunds WHERE student_id=? AND status='processed'),0) net_paid",[$id,$id,$id,$id,$id]);
  $creditSummary=one($pdo,"SELECT
    COALESCE(SUM(CASE WHEN status='paid' THEN credits_remaining ELSE 0 END),0) prepaid_lessons,
    COALESCE(SUM(CASE WHEN status='paid' AND credits_total>0 THEN total*credits_remaining/credits_total ELSE 0 END),0) prepaid_value,
    COALESCE(SUM(CASE WHEN status='unpaid' THEN credits_remaining ELSE 0 END),0) unpaid_bundle_lessons
    FROM bundles WHERE student_id=?",[$id]);
  $balance['prepaid_lessons']=$creditSummary['prepaid_lessons']??0;
  $balance['prepaid_value']=$creditSummary['prepaid_value']??0;
  $balance['unpaid_bundle_lessons']=$creditSummary['unpaid_bundle_lessons']??0;
  echo json_encode(['balance'=>$balance,'student'=>$student,'lessons'=>$history,'bundles'=>$bundles,'refunds'=>rows($pdo,'SELECT * FROM refunds WHERE student_id=? ORDER BY created_at DESC',[$id])]);exit;
 }
 if($_SERVER['REQUEST_METHOD']!=='POST')fail('POST required',405);
 if(!hash_equals($_SESSION['csrf'],(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))fail('Invalid session token',403);
 if($_SESSION['role']!=='admin')fail('Administrator permission required',403);
 if($action==='refund'){
  $lessonId=(int)($input['lesson_id']??0);$amount=round((float)($input['amount']??0),2);
  $status=(string)($input['status']??'pending');$reason=trim((string)($input['reason']??''));
  if($lessonId<1||$amount<=0||!in_array($status,['pending','processed'],true)||mb_strlen($reason)>1000)fail('Invalid refund');
  $pdo->beginTransaction();
  $l=one($pdo,"SELECT * FROM lessons WHERE id=? FOR UPDATE",[$lessonId]);
  if(!$l||$l['status']!=='cancelled'||$l['payment_status']!=='paid'||$l['kind']!=='standard')fail('Refunds require a cancelled, paid standalone lesson');
  $prior=one($pdo,"SELECT COALESCE(SUM(amount),0) total FROM refunds WHERE lesson_id=?",[$lessonId]);
  if($amount+(float)$prior['total']>(float)$l['price']+.001)fail('Refund exceeds remaining refundable amount');
  $pdo->prepare('INSERT INTO refunds(lesson_id,student_id,amount,status,reason) VALUES(?,?,?,?,?)')->execute([$lessonId,$l['student_id'],$amount,$status,$reason]);
  $pdo->commit();echo json_encode(['ok'=>true]);exit;
 }
 if($action==='update_student'){
  $id=(int)($input['id']??0);$name=trim((string)($input['name']??''));$email=trim((string)($input['email']??''));$phone=trim((string)($input['phone']??''));$dob=trim((string)($input['date_of_birth']??''));
  if($id<1||!$name||strlen($name)>120||strlen($email)>190||($email&&!filter_var($email,FILTER_VALIDATE_EMAIL)))fail('Invalid student details');if(strlen($phone)>35||($dob&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$dob))||($dob&&!checkdate((int)substr($dob,5,2),(int)substr($dob,8,2),(int)substr($dob,0,4)))||($dob>date('Y-m-d')))fail('Invalid phone or date of birth');
  $stmt=$pdo->prepare('UPDATE students SET name=?,email=?,phone=?,date_of_birth=? WHERE id=?');$stmt->execute([$name,$email,$phone,$dob?:null,$id]);if(!$stmt->rowCount()&&!one($pdo,'SELECT id FROM students WHERE id=?',[$id]))fail('Student not found',404);echo json_encode(['ok'=>true]);exit;
 }
 if($action==='update_teacher'){
  $id=(int)($input['id']??0);$name=trim((string)($input['name']??''));$instrument=trim((string)($input['instrument']??''));
  if($id<1||!$name||!$instrument||strlen($name)>120||strlen($instrument)>80)fail('Invalid teacher details');
  $stmt=$pdo->prepare('UPDATE teachers SET name=?,instrument=? WHERE id=?');$stmt->execute([$name,$instrument,$id]);if(!$stmt->rowCount()&&!one($pdo,'SELECT id FROM teachers WHERE id=?',[$id]))fail('Teacher not found',404);echo json_encode(['ok'=>true]);exit;
 }
 if($action==='delete_student'||$action==='delete_teacher'){
  $id=(int)($input['id']??0);
  if($id<1)fail('Invalid record');
  $isStudent=$action==='delete_student';
  $table=$isStudent?'students':'teachers';
  $column=$isStudent?'student_id':'teacher_id';
  $pdo->beginTransaction();
  $record=one($pdo,"SELECT id FROM $table WHERE id=? FOR UPDATE",[$id]);
  if(!$record)fail('Record not found',404);
  $lessonCount=one($pdo,"SELECT COUNT(*) n FROM lessons WHERE $column=?",[$id]);
  $bundleCount=$isStudent?one($pdo,'SELECT COUNT(*) n FROM bundles WHERE student_id=?',[$id]):['n'=>0];
  if((int)$lessonCount['n']>0||(int)$bundleCount['n']>0)
   fail('Cannot delete: this record has booking or financial history. Cancel upcoming bookings first; historical records must be retained.',409);
  $pdo->prepare("DELETE FROM $table WHERE id=?")->execute([$id]);
  $pdo->commit();echo json_encode(['ok'=>true]);exit;
 }
 if($action==='cancel_lesson'||$action==='lesson_status'||$action==='lesson_notes'){
  $id=(int)($input['id']??0);if($id<1)fail('Invalid lesson');
  $pdo->beginTransaction();
  $pdo->query('SELECT id FROM teachers ORDER BY id FOR UPDATE')->fetchAll();
  $l=one($pdo,'SELECT * FROM lessons WHERE id=? FOR UPDATE',[$id]);if(!$l)fail('Lesson not found',404);
  if($action==='lesson_notes'){
    $notes=trim((string)($input['notes']??''));if(mb_strlen($notes)>5000)fail('Notes too long');
    $pdo->prepare('UPDATE lessons SET notes=? WHERE id=?')->execute([$notes,$id]);
  }else{
    $status=$action==='cancel_lesson'?'cancelled':(string)($input['status']??'');
    if(!validStatus($status))fail('Invalid lesson status');
    $wasCancelled=$l['status']==='cancelled';$nowCancelled=$status==='cancelled';
    if($wasCancelled&&!$nowCancelled){
      if(conflict($pdo,(int)$l['student_id'],(int)$l['teacher_id'],$l['starts_at'],(int)$l['duration'],$l['room'],$id))fail('Cannot restore: conflicting booking');
      if($l['kind']==='trial'){
        $student=one($pdo,'SELECT trial_used FROM students WHERE id=? FOR UPDATE',[$l['student_id']]);
        if((int)$student['trial_used'])fail('Trial already used by another lesson');
        $pdo->prepare('UPDATE students SET trial_used=1 WHERE id=?')->execute([$l['student_id']]);
      }elseif($l['kind']==='bundle'){
        $b=one($pdo,'SELECT credits_remaining FROM bundles WHERE id=? FOR UPDATE',[$l['bundle_id']]);
        if(!$b||(int)$b['credits_remaining']<1)fail('No bundle credits available to restore');
        $pdo->prepare('UPDATE bundles SET credits_remaining=credits_remaining-1 WHERE id=?')->execute([$l['bundle_id']]);
      }
    }elseif(!$wasCancelled&&$nowCancelled){
      if($l['kind']==='bundle'&&$l['bundle_id'])$pdo->prepare('UPDATE bundles SET credits_remaining=credits_remaining+1 WHERE id=?')->execute([$l['bundle_id']]);
      if($l['kind']==='trial')$pdo->prepare('UPDATE students SET trial_used=0 WHERE id=?')->execute([$l['student_id']]);
    }
    $pdo->prepare('UPDATE lessons SET status=?,cancelled_at=? WHERE id=?')->execute([$status,$nowCancelled?date('Y-m-d H:i:s'):null,$id]);
  }
  $pdo->commit();echo json_encode(['ok'=>true]);exit;
 }
 if($action==='student'){$name=trim((string)($input['name']??''));$email=trim((string)($input['email']??''));$phone=trim((string)($input['phone']??''));$dob=trim((string)($input['date_of_birth']??''));if(!$name||strlen($name)>120||strlen($phone)>35||($email&&!filter_var($email,FILTER_VALIDATE_EMAIL))||($dob&&(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$dob)||!checkdate((int)substr($dob,5,2),(int)substr($dob,8,2),(int)substr($dob,0,4))||$dob>date('Y-m-d'))))fail('Invalid student details');$pdo->prepare('INSERT INTO students(name,email,phone,date_of_birth) VALUES(?,?,?,?)')->execute([$name,$email,$phone,$dob?:null]);echo json_encode(['ok'=>true]);exit;}
 if($action==='teacher'){$name=trim((string)($input['name']??''));if(!$name)fail('Teacher name required');$pdo->prepare('INSERT INTO teachers(name,instrument) VALUES(?,?)')->execute([$name,trim((string)($input['instrument']??''))]);echo json_encode(['ok'=>true]);exit;}
 if($action==='bundle'){
  $student=(int)($input['student_id']??0);$duration=(int)($input['duration']??0);$kind=(string)($input['kind']??'');$count=$kind==='new'?5:(int)($input['count']??0);
  if(!rate($duration)||!in_array($kind,['new','regular'],true)||($kind==='new'&&$count!==5)||($kind==='regular'&&($count<5||$count>100)))fail('Invalid bundle');
  $pdo->beginTransaction();$s=one($pdo,'SELECT * FROM students WHERE id=? FOR UPDATE',[$student]);if(!$s)fail('Student not found');
  if($kind==='new'&&((int)$s['first_bundle_used']||one($pdo,"SELECT id FROM lessons WHERE student_id=? AND kind='standard' AND status<>'cancelled' LIMIT 1",[$student])))fail('First-five offer no longer available');
  $total=round(rate($duration)*$count*($kind==='new'?.5:.9),2);$due=date('Y-m-d');
  $pdo->prepare('INSERT INTO bundles(student_id,kind,duration,credits_total,credits_remaining,total,due_date) VALUES(?,?,?,?,?,?,?)')->execute([$student,$kind,$duration,$count,$count,$total,$due]);
  if($kind==='new')$pdo->prepare('UPDATE students SET first_bundle_used=1 WHERE id=?')->execute([$student]);$pdo->commit();echo json_encode(['ok'=>true]);exit;
 }
 if($action==='book_series'){
  $student=(int)($input['student_id']??0);$teacher=(int)($input['teacher_id']??0);
  $duration=(int)($input['duration']??0);$start=(string)($input['starts_at']??'');
  $room=trim((string)($input['room']??'Room 1'));$kind=(string)($input['kind']??'standard');
  $bundleId=(int)($input['bundle_id']??0);$frequency=(string)($input['frequency']??'weekly');
  $count=(int)($input['count']??0);$notes=trim((string)($input['notes']??''));
  if(!rate($duration)||!in_array($frequency,['daily','weekly','fortnightly'],true)||$count<2||$count>52||!in_array($kind,['standard','bundle'],true)||!$room||mb_strlen($notes)>5000)fail('Invalid recurring booking');
  $first=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$start);
  if(!$first||$first->format('Y-m-d H:i:s')!==$start)fail('Invalid date/time');
  $interval=['daily'=>1,'weekly'=>7,'fortnightly'=>14][$frequency];$dates=[];
  for($i=0;$i<$count;$i++)$dates[]=$first->modify('+'.($i*$interval).' days')->format('Y-m-d H:i:s');
  $pdo->beginTransaction();
  $pdo->query('SELECT id FROM teachers ORDER BY id FOR UPDATE')->fetchAll();
  if(!one($pdo,'SELECT id FROM students WHERE id=?',[$student])||!one($pdo,'SELECT id FROM teachers WHERE id=?',[$teacher]))fail('Student or teacher not found');
  foreach($dates as $date)if(conflict($pdo,$student,$teacher,$date,$duration,$room))fail('Conflicting booking on '.$date,409);
  if($kind==='bundle'){
   $bundle=one($pdo,'SELECT * FROM bundles WHERE id=? AND student_id=? FOR UPDATE',[$bundleId,$student]);
   if(!$bundle||(int)$bundle['duration']!==$duration||(int)$bundle['credits_remaining']<$count)fail('Not enough matching bundle credits for all lessons');
   $pdo->prepare('UPDATE bundles SET credits_remaining=credits_remaining-? WHERE id=?')->execute([$count,$bundleId]);
  }
  $insert=$pdo->prepare('INSERT INTO lessons(student_id,teacher_id,starts_at,duration,room,kind,bundle_id,price,due_date,notes) VALUES(?,?,?,?,?,?,?,?,?,?)');
  foreach($dates as $date)$insert->execute([$student,$teacher,$date,$duration,$room,$kind,$kind==='bundle'?$bundleId:null,$kind==='bundle'?0:rate($duration),substr($date,0,10),$notes]);
  $pdo->commit();echo json_encode(['ok'=>true,'created'=>$count]);exit;
 }
 if($action==='book'||$action==='reschedule'){
  $id=(int)($input['id']??0);$existing=$id?one($pdo,'SELECT * FROM lessons WHERE id=?',[$id]):null;
  if($action==='reschedule'&&!$existing)fail('Lesson not found',404);if($existing&&$existing['status']==='cancelled')fail('Cancelled lessons cannot be rescheduled');
  $student=(int)($existing['student_id']??$input['student_id']??0);$teacher=(int)($input['teacher_id']??$existing['teacher_id']??0);
  $duration=(int)($existing['duration']??$input['duration']??0);$start=(string)($input['starts_at']??$existing['starts_at']??'');$room=trim((string)($input['room']??$existing['room']??'Room 1'));
  if(!rate($duration)||!preg_match('/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/',$start)||!strtotime($start)||!$room)fail('Invalid lesson fields');
  $pdo->beginTransaction();
  // Serialize writes so simultaneous booking requests cannot pass conflict validation together.
  $pdo->query('SELECT id FROM teachers ORDER BY id FOR UPDATE')->fetchAll();
  if(!one($pdo,'SELECT id FROM students WHERE id=?',[$student])||!one($pdo,'SELECT id FROM teachers WHERE id=?',[$teacher]))fail('Student or teacher not found');
  if(conflict($pdo,$student,$teacher,$start,$duration,$room,$id))fail('Teacher, student or room is already booked');
  if($action==='reschedule'){$pdo->prepare('UPDATE lessons SET starts_at=?,teacher_id=?,room=? WHERE id=?')->execute([$start,$teacher,$room,$id]);}
  else {
   $kind=(string)($input['kind']??'standard');$bundleId=null;$price=rate($duration);$notes=trim((string)($input['notes']??''));if(mb_strlen($notes)>5000)fail('Notes too long');
   if($kind==='trial'){$s=one($pdo,'SELECT trial_used FROM students WHERE id=? FOR UPDATE',[$student]);if($duration!==30||!$s||$s['trial_used'])fail('Free trial is only available once per student, for 30 minutes');$price=0;$pdo->prepare('UPDATE students SET trial_used=1 WHERE id=?')->execute([$student]);}
   elseif($kind==='bundle'){$bundleId=(int)($input['bundle_id']??0);$b=one($pdo,'SELECT * FROM bundles WHERE id=? AND student_id=? FOR UPDATE',[$bundleId,$student]);if(!$b||$b['duration']!=$duration||$b['credits_remaining']<1)fail('No matching bundle credits');$price=0;$pdo->prepare('UPDATE bundles SET credits_remaining=credits_remaining-1 WHERE id=?')->execute([$bundleId]);}
   elseif($kind!=='standard')fail('Invalid booking type');
   $pdo->prepare('INSERT INTO lessons(student_id,teacher_id,starts_at,duration,room,kind,bundle_id,price,due_date,notes) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$student,$teacher,$start,$duration,$room,$kind,$bundleId,$price,date('Y-m-d',strtotime($start)),$notes]);
  }
  $pdo->commit();echo json_encode(['ok'=>true]);exit;
 }
 if($action==='payment'){$type=$input['type']??'';$id=(int)($input['id']??0);$status=$input['status']??'';if(!in_array($type,['lesson','bundle'],true)||!in_array($status,['paid','unpaid'],true))fail('Invalid payment');$table=$type==='lesson'?'lessons':'bundles';$field=$type==='lesson'?'payment_status':'status';$pdo->prepare("UPDATE $table SET $field=? WHERE id=?")->execute([$status,$id]);echo json_encode(['ok'=>true]);exit;}
 fail('Unknown action',404);
} catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log($e->getMessage());fail('Request failed. Check server logs.',500);}
