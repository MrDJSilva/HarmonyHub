<?php
declare(strict_types=1);
// Set environment variables on the server; do not commit database passwords.
date_default_timezone_set(getenv('HH_TIMEZONE') ?: 'Australia/Perth');
$host=getenv('HH_DB_HOST') ?: '127.0.0.1';
$name=getenv('HH_DB_NAME') ?: 'harmonyhub';
$user=getenv('HH_DB_USER'); $pass=getenv('HH_DB_PASSWORD');
if($user===false || $pass===false) {http_response_code(503);exit(str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/') ? json_encode(['error'=>'Database configuration missing. Set HH_DB_USER and HH_DB_PASSWORD in Apache/PHP environment.']) : 'Database configuration missing');}
try {
 $pdo=new PDO('mysql:host='.$host.';dbname='.$name.';charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
} catch(PDOException $e){error_log('HarmonyHub database unavailable: '.$e->getCode());http_response_code(503);exit(str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/') ? json_encode(['error'=>'Database connection failed. Check database service, credentials, and HH_DB_NAME.']) : 'Service temporarily unavailable');}
