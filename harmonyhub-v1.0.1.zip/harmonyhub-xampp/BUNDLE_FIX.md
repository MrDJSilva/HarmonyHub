# New-student offer fix

## Cause
The frontend disabled the five-lesson quantity field for the introductory offer. Disabled form fields are omitted by FormData, so the API received a count of 0 and rejected it as `Invalid bundle`.

## Fix
The frontend explicitly sends five lessons for the introductory offer, and the API independently sets the introductory count to five. The eligibility checks for prior purchases and standard lessons remain unchanged.

## Installation
Back up your files and database. Replace `assets/app.js` and `api/index.php` from this package, keeping your existing `config.php` and database. Hard-refresh your browser (Ctrl+F5). No SQL migration is required.

## Test
1. Create a student with no lessons or bundles.
2. Select the introductory 50% offer, choose a duration, and submit. It should create five credits at half the regular price.
3. Check that the same student cannot purchase a second introductory offer.
4. Confirm a free trial remains separate and does not consume introductory credits.

If a new student still gets `First-five offer no longer available`, inspect `students.first_bundle_used` and existing `bundles` and `lessons` rows for that student before changing any data.
