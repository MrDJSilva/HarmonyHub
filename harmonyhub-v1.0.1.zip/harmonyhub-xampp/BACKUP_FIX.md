# Backup compatibility fix

Some upgraded V8 installations lack the `refunds` table. Previous backups unconditionally queried it, resulting in `Database operation failed`.

This update allows **export** without the optional `refunds` table, and lists omitted tables in `omitted_tables` in the JSON. It still refuses to omit missing core tables.

Restore validates table compatibility before deleting anything; it refuses a backup missing refunds when the target has refunds, to avoid inconsistent financial history. Restore remains destructive and untested on a live database.

## Install
Back up your database in phpMyAdmin. Copy **only** `settings.php` from this package into your existing installation. No migration required for the export fix.

## Recommended migration
If `refunds` is missing, apply `sql/migrate_v8.sql` only after inspecting it against your database and taking a full backup. Do not reimport `schema_production.sql` or overwrite existing tables.

If export still fails, check `C:\xampp\apache\logs\error.log` for `HarmonyHub settings:` and share the error text without student details or passwords.
