# HarmonyHub — hardened deployment candidate

See DEPLOYMENT.md for setup and outstanding production blockers. This is **not certified for live student data**.
