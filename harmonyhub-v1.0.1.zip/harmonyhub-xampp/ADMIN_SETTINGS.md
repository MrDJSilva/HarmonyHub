# Administrator settings, backup and restore

## Upgrade existing HarmonyHub (V8 or newer)
1. Back up your entire MySQL database using phpMyAdmin before upgrading.
2. Copy `settings.php` and `index.php` to your existing HarmonyHub folder (or deploy the complete ZIP without overwriting your configured `config.php`).
3. Run `sql/migrate_admin_settings.sql` against the existing `harmonyhub` database in phpMyAdmin.
4. Sign in as an administrator and select **Admin settings** in the dashboard header.

## Features
- Change own password (requires current password).
- Create other administrator accounts.
- Enable/disable administrators (cannot disable own account).
- Reset administrator passwords (requires current password).
- Download school data backup (JSON).
- Restore school data from HarmonyHub JSON backup.

## Backup limitations and safety
- The JSON export contains **personal data**. Encrypt it at rest and limit access.
- Backup includes teachers, students, bundles, lessons and refunds; **staff accounts, password hashes, and audit history are intentionally excluded**.
- Restore **replaces** these five tables; it does not merge. Always make a separate full MySQL backup before restore.
- Restore is limited to 10 MB uploads and must match the database's current schema.
- No automatic scheduled backups, cloud storage, or disaster recovery verification.
- A full database backup (e.g. mysqldump) remains necessary for complete recovery, including administrators, schema and audit log.
- Tested syntax only; validate export and restore on a separate staging database before production.
- Do not expose the application on the public internet without HTTPS, login rate limiting, permissions review, and independent security testing.
