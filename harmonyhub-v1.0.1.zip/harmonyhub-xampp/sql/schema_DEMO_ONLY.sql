CREATE DATABASE IF NOT EXISTS harmonyhub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE harmonyhub;
CREATE TABLE teachers (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,instrument VARCHAR(80) NOT NULL);
CREATE TABLE students (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,email VARCHAR(190),phone VARCHAR(35) NULL,date_of_birth DATE NULL,trial_used TINYINT(1) NOT NULL DEFAULT 0,first_bundle_used TINYINT(1) NOT NULL DEFAULT 0);
CREATE TABLE bundles (id INT AUTO_INCREMENT PRIMARY KEY,student_id INT NOT NULL,kind ENUM('new','regular') NOT NULL,duration INT NOT NULL,credits_total INT NOT NULL,credits_remaining INT NOT NULL,total DECIMAL(10,2) NOT NULL,status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',due_date DATE NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(student_id) REFERENCES students(id));
CREATE TABLE lessons (id INT AUTO_INCREMENT PRIMARY KEY,student_id INT NOT NULL,teacher_id INT NOT NULL,starts_at DATETIME NOT NULL,duration INT NOT NULL,room VARCHAR(80) NOT NULL DEFAULT 'Room 1',kind ENUM('standard','trial','bundle') NOT NULL DEFAULT 'standard',bundle_id INT NULL,price DECIMAL(10,2) NOT NULL, payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',status ENUM('scheduled','confirmed','completed','cancelled','no-show') NOT NULL DEFAULT 'scheduled',notes TEXT NULL,cancelled_at DATETIME NULL,due_date DATE NOT NULL,FOREIGN KEY(student_id) REFERENCES students(id),FOREIGN KEY(teacher_id) REFERENCES teachers(id),FOREIGN KEY(bundle_id) REFERENCES bundles(id), INDEX(teacher_id,starts_at),INDEX(student_id,starts_at));
INSERT INTO teachers(name,instrument) VALUES ('Sarah','Piano'),('Michael','Guitar'),('Daniel','Drums');
INSERT INTO students(name,email) VALUES ('Emma Wilson','emma@example.com'),('James Lee','james@example.com');


CREATE TABLE IF NOT EXISTS staff_users (id INT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(190) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,role ENUM('admin','teacher') NOT NULL DEFAULT 'teacher',active TINYINT(1) NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS refunds (id INT AUTO_INCREMENT PRIMARY KEY,lesson_id INT NOT NULL,student_id INT NOT NULL,amount DECIMAL(10,2) NOT NULL,status ENUM('pending','processed') NOT NULL DEFAULT 'pending',reason VARCHAR(1000),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(lesson_id) REFERENCES lessons(id),FOREIGN KEY(student_id) REFERENCES students(id));

CREATE TABLE IF NOT EXISTS admin_audit (id BIGINT AUTO_INCREMENT PRIMARY KEY, actor_id INT NULL, action VARCHAR(80) NOT NULL, details VARCHAR(255) NOT NULL DEFAULT '', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX(created_at));
