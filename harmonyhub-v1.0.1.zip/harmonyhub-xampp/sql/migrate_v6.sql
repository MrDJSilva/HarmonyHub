-- Run ONCE on an existing HarmonyHub database, after making a backup.
USE harmonyhub;
ALTER TABLE students ADD COLUMN phone VARCHAR(35) NULL, ADD COLUMN date_of_birth DATE NULL;
ALTER TABLE lessons ADD COLUMN status ENUM('scheduled','confirmed','completed','cancelled','no-show') NOT NULL DEFAULT 'scheduled', ADD COLUMN notes TEXT NULL, ADD COLUMN cancelled_at DATETIME NULL;
CREATE INDEX idx_student_history ON lessons(student_id,starts_at);
