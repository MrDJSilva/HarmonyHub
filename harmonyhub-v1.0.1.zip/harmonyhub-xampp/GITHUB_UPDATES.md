# GitHub-powered updates (safe release checker)

## Setup
1. Create a GitHub repository for HarmonyHub (public releases required for this implementation).
2. Set the Apache environment variable `HH_GITHUB_REPO` to `owner/repo` and restart Apache. For example: `SetEnv HH_GITHUB_REPO "your-org/harmonyhub"`. Do not put `SetEnv` in a PHP file.
3. Open **Admin settings → GitHub updates** and click **Check for updates**.
4. Publish stable GitHub Releases with tags like `v1.0.1`, and upload assets named `harmonyhub-update.zip` and `harmonyhub-update.zip.sha256`.
5. Release notes should document compatibility, database migrations, and rollback instructions.

## Update procedure
The dashboard shows the latest release and provides GitHub download links. It does NOT automatically apply an update or run arbitrary remote PHP. Verify SHA-256 with Windows `certutil -hashfile harmonyhub-update.zip SHA256` and compare with the published checksum. Back up the full MySQL database and application first, test on staging, then deploy.

## Security
- Only logged-in administrators can check for updates. CSRF token required.
- HTTPS certificate validation enabled; API requests go only to GitHub's fixed API host, with a strictly validated repository identifier.
- External release text is HTML escaped.
- This release checker does not authenticate GitHub release signatures, automatically verify ZIP hashes, install code, migrate databases or roll back failures. Those steps must be done manually.
- For private repositories, GitHub API authentication must be designed separately. Never embed a personal access token in frontend code.
