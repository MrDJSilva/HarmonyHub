# Prepaid credit balances

Student list and student profile show:
- Balance owing: outstanding unpaid standalone lessons and unpaid bundles.
- Prepaid credit: unused monetary value from **paid** bundles only.
- Prepaid lessons remaining: unused lesson credits from paid bundles.

Unused value per paid bundle = bundle total × credits_remaining / credits_total.
This respects discounted introductory and standard bundle prices; it is not the full undiscounted lesson price.

Unpaid bundles are not considered prepaid funds, even if their credits can currently be used by the booking system. This update is display-only; it does not enforce payment before consuming credits.

These values are estimates of unconsumed lesson entitlement, **not refundable cash balances**. Refunds of bundles and payment reconciliation require additional ledger logic.

## Install
Back up your database and files. Replace only `api/index.php` and `assets/app.js` from this package. Keep your existing `config.php`, database and authentication files. No SQL migration is required.
