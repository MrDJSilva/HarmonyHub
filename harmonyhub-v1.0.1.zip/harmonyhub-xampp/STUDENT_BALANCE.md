# Student balance update

Student list and student profile display balance owing (AUD), calculated from unpaid standalone lessons that are not cancelled plus unpaid bundles. Prepaid lessons are not charged twice. Completed refunds reduce net payments received only once processed; pending refunds do not change totals. Cancelled paid lessons remain in paid totals until refunded. This is an accounts receivable balance, not a remaining lesson-credit balance; credits remain on the Bundles tab.

Install: back up your site and database; copy only `api/index.php` and `assets/app.js` into your current site. No SQL migration required if the existing V8 refund tables are installed.
