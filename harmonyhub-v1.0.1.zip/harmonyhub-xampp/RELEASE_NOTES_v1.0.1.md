# HarmonyHub v1.0.1 — GitHub Release

## Included
- Music school calendar, students, teachers, lesson booking, bundles, balances and prepaid credit.
- Administrator settings: password changes, admin account management.
- School-data JSON backup and restore, with optional refunds-table compatibility and audit logging tolerance.
- Admin-only school data reset (Danger Zone) with confirmation.
- Dashboard settings navigation and GitHub Releases update checker.

## Existing installation upgrade
1. Export your MySQL database through phpMyAdmin and back up the whole HarmonyHub directory.
2. Unzip the release and copy application files into the existing HarmonyHub directory. **Do not overwrite `config.php`.**
3. Run `sql/migrate_admin_settings.sql` in phpMyAdmin if it has not been applied already. Existing V8 deployments may also need `sql/migrate_v6.sql` and `sql/migrate_v8.sql`; apply only missing migrations.
4. Confirm `version.php` returns `1.0.1`. Test login, lessons, backups and restores on a staging copy first.

## Fresh installation
- Use `sql/schema_production.sql` to create tables in a new empty database, configure `config.php` or environment variables, and create the first administrator using `bin/create_admin.php`. Consult README and DEPLOYMENT.
- `sql/schema_DEMO_ONLY.sql` is sample/demo data and must not be imported into an existing database.

## GitHub Release
- Tag: `v1.0.1`
- Upload `harmonyhub-update.zip` and `harmonyhub-update.zip.sha256` as release assets.
- Configure `HH_GITHUB_REPO` to `owner/repo` in Apache for the built-in update checker.

## Notes
- Do not commit `config.php` with real credentials or any exported school backup to a public repository.
- Backups exported by Admin Settings omit administrator accounts and database schema; keep a full SQL backup separately.
- The GitHub updater checks and links to releases; it does not auto-install.
- PHP syntax checked; no live XAMPP/MySQL integration tests performed.
