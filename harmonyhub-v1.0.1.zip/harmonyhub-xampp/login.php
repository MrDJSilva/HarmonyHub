<?php
require __DIR__.'/auth.php';
if(!empty($_SESSION['uid'])){header('Location: index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 require __DIR__.'/config.php';
 $email=trim((string)($_POST['email']??''));$password=(string)($_POST['password']??'');
 $q=$pdo->prepare('SELECT id,password_hash,role FROM staff_users WHERE email=? AND active=1');$q->execute([$email]);$user=$q->fetch();
 if($user&&password_verify($password,$user['password_hash'])){session_regenerate_id(true);$_SESSION['uid']=(int)$user['id'];$_SESSION['role']=$user['role'];$_SESSION['csrf']=bin2hex(random_bytes(32));header('Location: index.php');exit;}
 $error='Invalid login details';sleep(1);
}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HarmonyHub sign in</title><link rel="stylesheet" href="assets/app.css"><main style="max-width:420px;margin:12vh auto;padding:28px" class="panel"><h1>HarmonyHub</h1><p>Staff sign in</p><?php if($error):?><p role="alert"><?=htmlspecialchars($error)?></p><?php endif;?><form method="post"><label>Email<input type="email" name="email" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="btn primary">Sign in</button></form></main></html>