<?php
require __DIR__.'/auth.php';require_login();require __DIR__.'/config.php';
if(($_SESSION['role']??'')!=='admin'){http_response_code(403);exit('Administrators only');}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function verifyAdmin(PDO $pdo,string $password):bool {$q=$pdo->prepare("SELECT password_hash FROM staff_users WHERE id=? AND active=1 AND role='admin'");$q->execute([$_SESSION['uid']]);$hash=$q->fetchColumn();return is_string($hash)&&password_verify($password,$hash);}
function audit(PDO $pdo,string $action,string $details=''):void {
 // Audit logging must never prevent a valid school-data export.
 try {
  $columns=$pdo->query('SHOW COLUMNS FROM `admin_audit`')->fetchAll(PDO::FETCH_COLUMN);
  $actor=in_array('actor_id',$columns,true)?'actor_id':(in_array('admin_id',$columns,true)?'admin_id':null);
  if($actor!==null){
   $stmt=$pdo->prepare('INSERT INTO `admin_audit` (`'.$actor.'`,`action`,`details`) VALUES (?,?,?)');
   $stmt->execute([$_SESSION['uid'],$action,$details]);
  } else {error_log('HarmonyHub settings: audit skipped (missing actor column)');}
 }catch(Throwable $e){error_log('HarmonyHub settings: audit unavailable: '.$e->getMessage());}
}
function postCsrf():void {if(!hash_equals((string)($_SESSION['csrf']??''),(string)($_POST['csrf']??''))){http_response_code(403);exit('Invalid session token');}}
$tables=['teachers','students','bundles','lessons','refunds'];
$message='';$error='';
try {
 if($_SERVER['REQUEST_METHOD']==='POST'){
  postCsrf();$action=(string)($_POST['action']??'');
  if($action==='backup'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect administrator password');
   // Earlier HarmonyHub databases may not yet contain the optional refunds table.
   // Do not silently omit core school data or fabricate a table.
   $existing=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
   $missing=array_values(array_diff($tables,$existing));
   $requiredMissing=array_values(array_diff($missing,['refunds']));
   if($requiredMissing){throw new RuntimeException('Backup cannot proceed: missing required table(s): '.implode(', ',$requiredMissing));}
   $data=[];
   foreach($tables as $t){
    if(in_array($t,$missing,true))continue;
    $data[$t]=$pdo->query('SELECT * FROM `'.$t.'` ORDER BY `id`')->fetchAll(PDO::FETCH_ASSOC);
   }
   $payload=['format'=>'harmonyhub-school-backup-v1','created_at'=>gmdate('c'),'tables'=>$data,'omitted_tables'=>$missing];
   $json=json_encode($payload,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
   audit($pdo,'backup_export','School data only; excludes staff credentials');
   header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="harmonyhub-backup-'.date('Ymd-His').'.json"');header('X-Content-Type-Options: nosniff');echo $json;exit;
  }
  if($action==='restore'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect administrator password');
   if(($_POST['confirm']??'')!=='RESTORE')throw new RuntimeException('Type RESTORE to confirm');
   if(!isset($_FILES['backup'])||$_FILES['backup']['error']!==UPLOAD_ERR_OK||$_FILES['backup']['size']>10*1024*1024)throw new RuntimeException('Upload a valid backup under 10 MB');
   $raw=file_get_contents($_FILES['backup']['tmp_name']);$obj=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
   if(($obj['format']??'')!=='harmonyhub-school-backup-v1'||!isset($obj['tables'])||!is_array($obj['tables']))throw new RuntimeException('Unsupported backup format');
   $restoreTables=array_keys($obj['tables']);
   if(array_diff($restoreTables,$tables)||array_diff(['teachers','students','bundles','lessons'],$restoreTables))throw new RuntimeException('Backup has missing required tables or unexpected tables');
   $restoreTables=array_values(array_intersect($tables,$restoreTables));
   $existing=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
   if(array_diff($restoreTables,$existing))throw new RuntimeException('Restore blocked: target database is missing tables included in backup. Apply database migrations first.');
   if(!in_array('refunds',$restoreTables,true)&&in_array('refunds',$existing,true))throw new RuntimeException('Restore blocked: backup omits refunds but target has a refunds table. Restore using a full compatible backup to avoid orphaned financial history.');
   $columns=[];foreach($restoreTables as $t){if(!is_array($obj['tables'][$t])||count($obj['tables'][$t])>100000)throw new RuntimeException('Invalid backup records');$columns[$t]=array_column($pdo->query('SHOW COLUMNS FROM `'.$t.'`')->fetchAll(PDO::FETCH_ASSOC),'Field');foreach($obj['tables'][$t] as $row){if(!is_array($row)||array_diff(array_keys($row),$columns[$t])||!isset($row['id']))throw new RuntimeException('Backup contains unexpected columns or missing IDs');}}
   $pdo->beginTransaction();
   try{
    foreach(array_reverse($restoreTables) as $t)$pdo->exec('DELETE FROM `'.$t.'`');
    foreach($restoreTables as $t)foreach($obj['tables'][$t] as $row){$keys=array_keys($row);$sql='INSERT INTO `'.$t.'` ('.implode(',',array_map(fn($k)=>'`'.$k.'`',$keys)).') VALUES ('.implode(',',array_fill(0,count($keys),'?')).')';$pdo->prepare($sql)->execute(array_values($row));}
    audit($pdo,'backup_restore','Restored school data from uploaded JSON');$pdo->commit();$message='School data restored successfully. Staff accounts were preserved.';
   }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
  }
  if($action==='password'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect current password');
   $new=(string)($_POST['new_password']??'');if(strlen($new)<14||strlen($new)>256||$new!==($_POST['confirm_password']??''))throw new RuntimeException('New passwords must match and contain 14–256 characters');
   $pdo->prepare('UPDATE staff_users SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$_SESSION['uid']]);session_regenerate_id(true);audit($pdo,'password_change');$message='Password changed.';
  }
  if($action==='create'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect administrator password');
   $email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['new_password']??'');
   if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<14||strlen($password)>256)throw new RuntimeException('Valid email and password of 14–256 characters required');
   $pdo->prepare("INSERT INTO staff_users(email,password_hash,role,active) VALUES(?,?,'admin',1)")->execute([$email,password_hash($password,PASSWORD_DEFAULT)]);audit($pdo,'admin_created',$email);$message='Administrator created.';
  }
  if($action==='toggle'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect administrator password');
   $id=(int)($_POST['user_id']??0);$target=$pdo->prepare("SELECT id,email,active FROM staff_users WHERE id=? AND role='admin'");$target->execute([$id]);$u=$target->fetch();if(!$u)throw new RuntimeException('Administrator not found');if($id===$_SESSION['uid'])throw new RuntimeException('Cannot deactivate your own account');
   if($u['active']){$active=(int)$pdo->query("SELECT COUNT(*) FROM staff_users WHERE role='admin' AND active=1")->fetchColumn();if($active<=1)throw new RuntimeException('Cannot deactivate the last active administrator');}
   $pdo->prepare('UPDATE staff_users SET active=? WHERE id=?')->execute([$u['active']?0:1,$id]);audit($pdo,'admin_status_changed',$u['email']);$message='Administrator status updated.';
  }
  if($action==='reset'){
   if(!verifyAdmin($pdo,(string)($_POST['current_password']??'')))throw new RuntimeException('Incorrect administrator password');
   $id=(int)($_POST['user_id']??0);$password=(string)($_POST['new_password']??'');if(strlen($password)<14||strlen($password)>256)throw new RuntimeException('Password must contain 14–256 characters');
   $stmt=$pdo->prepare("UPDATE staff_users SET password_hash=? WHERE id=? AND role='admin'");$stmt->execute([password_hash($password,PASSWORD_DEFAULT),$id]);if(!$stmt->rowCount())throw new RuntimeException('Administrator not found');audit($pdo,'admin_password_reset',(string)$id);$message='Administrator password reset.';
  }
 }
}catch(Throwable $e){$error=($e instanceof PDOException)?'Database operation failed. Check the server log.':$e->getMessage();error_log('HarmonyHub settings: '.$e->getMessage());}
$admins=$pdo->query("SELECT id,email,active FROM staff_users WHERE role='admin' ORDER BY id")->fetchAll();
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HarmonyHub · Settings</title><link rel="stylesheet" href="assets/app.css"><style>body{padding:2rem;max-width:1100px;margin:auto}.settings-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem}.panel{padding:1.5rem}form{display:grid;gap:.65rem;margin:1rem 0}input{width:100%;padding:.7rem}label{display:grid;gap:.3rem}.notice{padding:1rem;background:#174b39}.error{padding:1rem;background:#662d2d}.muted{opacity:.8}table{width:100%}</style><header><h1>HarmonyHub · Admin settings</h1><p><a class="btn subtle" href="index.php">← Dashboard</a> <a class="btn subtle" href="logout.php">Sign out</a></p></header><?php if($message):?><p class="notice" role="status"><?=h($message)?></p><?php endif;?><?php if($error):?><p class="error" role="alert"><?=h($error)?></p><?php endif;?><p><a class="btn subtle" href="updates.php">↻ GitHub updates</a></p><div class="settings-grid"><section class="panel"><h2>Change my password</h2><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="password"><label>Current password<input type="password" name="current_password" required></label><label>New password (14+ characters)<input type="password" name="new_password" minlength="14" required></label><label>Confirm new password<input type="password" name="confirm_password" minlength="14" required></label><button class="btn primary">Change password</button></form></section><section class="panel"><h2>Add administrator</h2><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="create"><label>Email<input type="email" name="email" required></label><label>Temporary password (14+ characters)<input type="password" name="new_password" minlength="14" required></label><label>Your current password<input type="password" name="current_password" required></label><button class="btn primary">Create administrator</button></form></section><section class="panel"><h2>Download backup</h2><p class="muted">Exports students, teachers, lessons, bundles and refunds. Admin accounts and passwords are excluded. Contains sensitive student data: store securely.</p><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="backup"><label>Your password<input type="password" name="current_password" required></label><button class="btn primary">Download JSON backup</button></form></section><section class="panel"><h2>Restore backup</h2><p class="muted"><strong>Danger:</strong> Replaces existing school data. Back up your current database first. Only restore trusted HarmonyHub backups; staff accounts remain unchanged. Maximum 10 MB.</p><form method="post" enctype="multipart/form-data" onsubmit="return confirm('Replace all current school data with this backup? This cannot be undone.');"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="restore"><label>Backup file<input type="file" name="backup" accept=".json,application/json" required></label><label>Your password<input type="password" name="current_password" required></label><label>Type RESTORE<input name="confirm" required pattern="RESTORE"></label><button class="btn primary">Restore school data</button></form></section><section class="panel" style="border:2px solid #a33"><h2>Danger zone · Clear school data</h2><p class="muted">Permanently delete all students, teachers, lessons, bundles and refunds. Administrator accounts and settings are preserved. This cannot be undone.</p><p><a class="btn subtle" href="nuke_settings.php">Open data reset settings →</a></p></section></div><section class="panel"><h2>Manage administrators</h2><table><thead><tr><th>Email</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach($admins as $u):?><tr><td><?=h($u['email'])?><?php if($u['id']===$_SESSION['uid'])echo ' (you)';?></td><td><?=$u['active']?'Active':'Disabled'?></td><td><?php if($u['id']!==$_SESSION['uid']):?><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="user_id" value="<?=h($u['id'])?>"><label>Your password<input type="password" name="current_password" required></label><button class="btn subtle"><?=$u['active']?'Disable':'Enable'?></button></form><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="reset"><input type="hidden" name="user_id" value="<?=h($u['id'])?>"><label>New password<input type="password" name="new_password" minlength="14" required></label><label>Your password<input type="password" name="current_password" required></label><button class="btn subtle">Reset password</button></form></td></tr><?php endforeach;?></tbody></table></section></html>
