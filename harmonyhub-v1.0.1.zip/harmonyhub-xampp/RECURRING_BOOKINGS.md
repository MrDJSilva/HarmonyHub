# Multiple and recurring lessons

The New booking form supports one-time, daily, weekly and fortnightly bookings (2–52 lessons). It creates separate lesson records for the same student, with teacher/room/student overlap checks.

All occurrences are created in a single transaction: a conflicting date rejects the whole series, leaving existing lessons and bundle credits unchanged. Each occurrence can subsequently be rescheduled, cancelled or marked completed independently.

For prepaid bundles, sufficient matching credits must exist for **all** occurrences before creating the series; credits are deducted together. Free trials are single bookings only. Standard lessons generate one unpaid charge per occurrence.

No database migration is required. This does not automatically create future lessons beyond the selected number, and it does not include series-wide editing/cancellation.

Install only `api/index.php`, `assets/app.js`, and `index.php` over your current installation; keep `config.php` and database. Back up files and DB first.
