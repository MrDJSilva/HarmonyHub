# HarmonyHub deployment candidate (not production certified)

## Requirements
- PHP 8.1+ with PDO MySQL, Apache, MySQL/MariaDB, HTTPS certificate, secure host, backups and monitoring.
- Set `HH_DB_HOST`, `HH_DB_NAME`, `HH_DB_USER`, `HH_DB_PASSWORD` and optional `HH_TIMEZONE` in server environment. Create a least-privileged MySQL account. Do not use root.
- On a **new, empty** database import `sql/schema_production.sql` (no demo students); on an existing V8 database, back it up and keep its current schema.
- Create the first admin via server CLI: `php bin/create_admin.php admin@example.com`. No browser-based setup page is shipped.
- Deploy to a staging server first; check login, booking overlaps, cancellation, credits, payment states, refunds and reports.
- Configure encrypted daily database backups and practice restoring them. Protect database credentials, audit access, and apply appropriate child-data privacy rules.

## Important blockers before real production use
- **Not production certified**: no end-to-end XAMPP/live-server integration tests, security penetration tests or load tests.
- No persistent login rate limiting, MFA, detailed audit log, per-teacher access, or automated refund settlement.
- Business revenue still reports manually marked paid amounts and does not net out processed refunds. Do not use as reconciled accounting figures.
- Cancelled lessons and financial records require stronger lifecycle/audit controls.
- Password prompt is echoed by CLI and should be improved for operational use.
- Configure web-server TLS, firewall, security headers and backups before deployment.

Use only demonstration data until these gaps are closed.
