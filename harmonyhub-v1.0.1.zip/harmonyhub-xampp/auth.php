<?php
declare(strict_types=1);
ini_set('session.use_strict_mode','1');
ini_set('session.use_only_cookies','1');
ini_set('session.cookie_httponly','1');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store, private');
if(session_status()!==PHP_SESSION_ACTIVE){
 $secure=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off');
 session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Strict','path'=>'/']);
 session_start();
}
function require_login():void {
 if(empty($_SESSION['uid'])){
  http_response_code(401);
  if(str_contains($_SERVER['REQUEST_URI']??'','/api/')){header('Content-Type: application/json');echo json_encode(['error'=>'Please sign in']);}
  else{header('Location: login.php');}
  exit;
 }
}
