<?php
declare(strict_types=1);
require __DIR__.'/auth.php';
require_login();
require __DIR__.'/config.php';
if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit('Administrators only'); }
function esc(string $v): string { return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$error = '';
$success = '';
$counts = [];
$required = ['students', 'teachers', 'bundles', 'lessons'];
$ordered = ['refunds', 'lessons', 'bundles', 'students', 'teachers'];
try {
    $existing = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $missing = array_diff($required, $existing);
    if ($missing) { throw new RuntimeException('Database is missing required tables: '.implode(', ', $missing)); }
    foreach ($ordered as $table) {
        if (in_array($table, $existing, true)) {
            $counts[$table] = (int) $pdo->query('SELECT COUNT(*) FROM `'.$table.'`')->fetchColumn();
        }
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $csrf = (string) ($_POST['csrf'] ?? '');
        if (empty($_SESSION['csrf']) || !hash_equals((string)$_SESSION['csrf'], $csrf)) {
            throw new RuntimeException('Invalid session token. Refresh the page.');
        }
        if (($_POST['confirm'] ?? '') !== 'DELETE ALL SCHOOL DATA' || ($_POST['confirm_again'] ?? '') !== 'DELETE ALL SCHOOL DATA') {
            throw new RuntimeException('Type DELETE ALL SCHOOL DATA in both confirmation fields.');
        }
        $password = (string) ($_POST['current_password'] ?? '');
        $stmt = $pdo->prepare("SELECT password_hash FROM staff_users WHERE id=? AND active=1 AND role='admin'");
        $stmt->execute([$_SESSION['uid']]);
        $hash = $stmt->fetchColumn();
        if (!is_string($hash) || !password_verify($password, $hash)) {
            throw new RuntimeException('Incorrect administrator password.');
        }
        // Delete child rows first, retaining foreign-key enforcement and full rollback on failure.
        $pdo->beginTransaction();
        try {
            foreach ($ordered as $table) {
                if (array_key_exists($table, $counts)) { $pdo->exec('DELETE FROM `'.$table.'`'); }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            throw $e;
        }
        // Audit logging is best-effort and must not undo or misreport a successful reset.
        try {
            $auditColumns = $pdo->query('SHOW COLUMNS FROM `admin_audit`')->fetchAll(PDO::FETCH_COLUMN);
            $actor = in_array('actor_id', $auditColumns, true) ? 'actor_id' : (in_array('admin_id', $auditColumns, true) ? 'admin_id' : null);
            if ($actor !== null) {
                $log = $pdo->prepare('INSERT INTO `admin_audit` (`'.$actor.'`, `action`, `details`) VALUES (?, ?, ?)');
                $log->execute([$_SESSION['uid'], 'school_data_reset', 'Administrator cleared school records']);
            }
        } catch (Throwable $e) { error_log('HarmonyHub reset audit: '.$e->getMessage()); }
        $success = 'School data permanently cleared. Administrator accounts were preserved.';
        foreach ($counts as $table => $_) { $counts[$table] = 0; }
    }
} catch (Throwable $e) {
    $error = $e instanceof PDOException ? 'Database operation failed. Check the Apache/PHP error log.' : $e->getMessage();
    error_log('HarmonyHub data reset: '.$e->getMessage());
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HarmonyHub · Clear school data</title><link rel="stylesheet" href="assets/app.css"><style>body{max-width:720px;margin:2rem auto;padding:1rem}.danger{border:2px solid #ad4242;border-radius:12px;padding:1.5rem}label{display:block;margin:1rem 0}input{display:block;width:100%;box-sizing:border-box;padding:.8rem;margin-top:.4rem}button{padding:.9rem 1.3rem;background:#aa3333;color:white;border:0;border-radius:8px;cursor:pointer}.error{color:#ff8d8d}.success{color:#7dddac}.muted{opacity:.85}li{margin:.3rem 0}</style></head><body><p><a href="settings.php">← Back to Admin Settings</a></p><main class="danger"><h1>Clear all school data</h1><p><strong>PERMANENT DELETION.</strong> This clears every student, teacher, lesson, prepaid bundle and refund record. Existing administrator accounts and their passwords remain intact.</p><p><strong>Make a full database backup in phpMyAdmin first.</strong> Do not continue if you need to retain any school history.</p><?php if($error): ?><p class="error" role="alert"><?=esc($error)?></p><?php endif; ?><?php if($success): ?><p class="success" role="status"><?=esc($success)?></p><?php endif; ?><h2>Records currently stored</h2><ul><?php foreach($counts as $table=>$count): ?><li><?=esc(ucfirst($table))?>: <?=number_format($count)?></li><?php endforeach; ?></ul><?php if(!$success && !$error || (!$success && $counts)): ?><form method="post" onsubmit="return confirm('FINAL WARNING: Permanently erase ALL students, teachers, lessons, bundles and refunds?');"><input type="hidden" name="csrf" value="<?=esc((string)($_SESSION['csrf']??''))?>"><label>Type DELETE ALL SCHOOL DATA<input name="confirm" autocomplete="off" required pattern="DELETE ALL SCHOOL DATA"></label><label>Type DELETE ALL SCHOOL DATA again<input name="confirm_again" autocomplete="off" required pattern="DELETE ALL SCHOOL DATA"></label><label>Your administrator password<input type="password" name="current_password" required autocomplete="current-password"></label><button type="submit">Permanently delete school data</button></form><?php endif; ?></main></body></html>
