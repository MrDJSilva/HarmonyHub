# XAMPP database error troubleshooting

If you see `Unexpected token D` or `Database configuration missing`, the PHP API did not connect to MySQL.

1. Start Apache and MySQL in the XAMPP control panel.
2. Confirm `harmonyhub` exists in phpMyAdmin and that its schema is installed.
3. Set the environment variables `HH_DB_HOST`, `HH_DB_NAME`, `HH_DB_USER`, `HH_DB_PASSWORD` in the Apache server environment. On local Windows XAMPP, use Apache `SetEnv` directives in a **private, server-only** Apache configuration file, not in a public web-accessible file. Restart Apache. Do not use the root account for deployment.
4. Reload the dashboard. Check the Network tab for `api/index.php?action=overview` and inspect its HTTP status and JSON response.
5. Review Apache/PHP error logs if the API still fails. Do not display raw database exceptions to users.

This patch improves API error messages. It does not automatically configure database credentials or repair an absent schema.
